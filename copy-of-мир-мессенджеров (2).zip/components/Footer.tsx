
import React, { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';

const Footer: React.FC = () => {
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    setCurrentUrl(window.location.href);
  }, []);

  const shareLinks = [
    { name: 'Telegram', icon: 'fa-telegram', color: 'bg-[#229ED9]', url: `https://t.me/share/url?url=${currentUrl}&text=Посмотри наш научный проект 6-З класса о мессенджерах!` },
    { name: 'WhatsApp', icon: 'fa-whatsapp', color: 'bg-[#25D366]', url: `https://api.whatsapp.com/send?text=Наш первый научный проект: ${currentUrl}` },
    { name: 'VK', icon: 'fa-vk', color: 'bg-[#0077FF]', url: `https://vk.com/share.php?url=${currentUrl}` }
  ];

  return (
    <footer className="bg-blue-950 border-t border-blue-800 py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 mb-16 items-start">
          
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-white p-2 rounded-xl">
                <i className="fas fa-graduation-cap text-blue-900 text-xl"></i>
              </div>
              <span className="text-xl font-black tracking-tighter uppercase">Научный проект 6 «З»</span>
            </div>
            <p className="text-blue-300 text-sm leading-relaxed max-w-sm mb-8 italic">
              «Этот сайт — результат нашего первого научного исследования. Мы учимся работать с информацией и создавать полезные цифровые продукты».
            </p>
            
            <div className="flex flex-wrap gap-3">
              <p className="w-full text-[10px] font-black uppercase text-blue-500 mb-2 tracking-widest">Поделиться проектом:</p>
              {shareLinks.map((link) => (
                <a 
                  key={link.name}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${link.color} text-white px-4 py-2 rounded-xl flex items-center space-x-2 text-xs font-bold hover:scale-105 transition-transform shadow-lg shadow-black/20`}
                >
                  <i className={`fab ${link.icon}`}></i>
                  <span>{link.name}</span>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-blue-500 mb-6">Организаторы</h4>
            <p className="text-blue-100 font-bold mb-2 uppercase tracking-tighter">Ученики 6 класса «З»</p>
            <div className="space-y-3 mt-4">
              <div>
                <p className="text-blue-400 text-[10px] uppercase font-black tracking-widest">Учитель:</p>
                <p className="text-white font-bold">Любовь Николаевна</p>
              </div>
              <div>
                <p className="text-blue-400 text-[10px] uppercase font-black tracking-widest">Руководитель:</p>
                <p className="text-white font-bold">Сергей Сергеевич</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center lg:items-end">
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-blue-500 mb-6">Для мобильных</h4>
            <div className="bg-white p-3 rounded-2xl shadow-2xl border-4 border-blue-400/20">
              {currentUrl ? (
                <QRCodeSVG value={currentUrl} size={80} />
              ) : (
                <div className="w-[80px] h-[80px] bg-gray-200 animate-pulse"></div>
              )}
            </div>
            <p className="text-[9px] font-black text-blue-400 mt-4 uppercase tracking-widest">Сканируй для входа</p>
          </div>
        </div>
        
        <div className="pt-8 border-t border-blue-900/50 text-center">
          <p className="text-blue-500 text-[10px] font-black uppercase tracking-widest">
            Школа 2024 • Первый научный проект • 6 «З» класс
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
