
import React from 'react';

const messengers = [
  {
    name: 'WhatsApp',
    icon: 'fa-whatsapp',
    color: 'from-green-400 to-green-600',
    tag: 'Связь с семьей',
    desc: 'В нашем исследовании мы выяснили, что это самый популярный мессенджер среди наших родителей. Он прост и надежен для звонков бабушкам и дедушкам.'
  },
  {
    name: 'Telegram',
    icon: 'fa-telegram',
    color: 'from-sky-400 to-sky-600',
    tag: 'Для творчества',
    desc: 'Это наша любимая площадка. Здесь мы смотрим ютуберов, создаем свои стикерпаки и ведем школьные каналы. Telegram помогает стать популярным!'
  },
  {
    name: 'Discord',
    icon: 'fa-discord',
    color: 'from-indigo-400 to-indigo-600',
    tag: 'Для команд',
    desc: 'Мы используем его для совместных игр и подготовки уроков. Здесь можно создать свой аккаунт и общаться голосом, как в настоящей лаборатории.'
  }
];

const MessengerShowcase: React.FC = () => {
  return (
    <section id="showcase" className="py-20 bg-blue-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black mb-4 uppercase italic tracking-tighter">Результаты нашего исследования</h2>
          <div className="w-24 h-1 bg-blue-500 mx-auto mb-6"></div>
          <p className="text-blue-200 text-lg max-w-2xl mx-auto">Мы изучили функции мессенджеров, которые чаще всего скачивают в Play Market. Вот наши выводы:</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {messengers.map((m, i) => (
            <div key={i} className="group bg-blue-800/50 border border-blue-400/20 p-8 rounded-[2rem] hover:scale-[1.02] transition-all duration-300">
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center mb-6 shadow-lg`}>
                <i className={`fab ${m.icon} text-2xl text-white`}></i>
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-2">{m.tag}</span>
              <h3 className="text-2xl font-black mb-4">{m.name}</h3>
              <p className="text-blue-100/80 leading-relaxed text-sm">
                {m.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MessengerShowcase;
