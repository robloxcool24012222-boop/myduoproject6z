
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-blue-900/95 backdrop-blur-lg shadow-xl border-b border-blue-400/30">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-3 group cursor-pointer">
          <div className="bg-white p-2 rounded-xl transition-transform group-hover:scale-110 shadow-lg shadow-blue-500/20">
            <i className="fas fa-graduation-cap text-blue-700 text-xl"></i>
          </div>
          <div>
            <span className="text-xl font-black tracking-tighter text-white block leading-none">НАУЧНЫЙ ПРОЕКТ</span>
            <span className="text-[10px] font-bold text-blue-300 uppercase tracking-widest">6 «З» КЛАСС • 2024</span>
          </div>
        </div>
        <nav className="hidden lg:flex space-x-8">
          <a href="#home" className="text-xs font-bold hover:text-blue-300 transition-colors uppercase tracking-widest">О проекте</a>
          <a href="#showcase" className="text-xs font-bold hover:text-blue-300 transition-colors uppercase tracking-widest">Исследование</a>
          <a href="#assistant" className="text-xs font-bold hover:text-blue-300 transition-colors uppercase tracking-widest">Лаборатория ИИ</a>
        </nav>
        <div className="flex items-center space-x-4">
           <div className="hidden sm:block px-3 py-1 bg-blue-500/20 border border-blue-400/50 rounded-full text-[10px] font-bold">
            ПЕРВАЯ РАБОТА
           </div>
           <button className="bg-white text-blue-900 px-5 py-2 rounded-xl font-bold text-sm hover:bg-blue-50 transition-all shadow-lg active:scale-95">
            Меню
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
