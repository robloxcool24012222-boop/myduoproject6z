
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

const GeminiAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'Привет! Я виртуальный ассистент научного проекта 6 «З» класса. Мы изучаем, как работают мессенджеры. Любовь Николаевна и Сергей Сергеевич помогли нам собрать эту базу данных. Что тебе подсказать?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          { role: 'user', parts: [{ text: userMsg }] }
        ],
        config: {
          systemInstruction: `Вы — цифровой помощник научного проекта учеников 6 «З» класса. 
          Проект посвящен популярным мессенджерам (WhatsApp, Telegram, Discord). 
          Учитель проекта: Любовь Николаевна. Руководитель: Сергей Сергеевич.
          Отвечайте дружелюбно, просто, как будто вы помогаете одноклассникам или их родителям. 
          Подчеркивайте, что это первая научная работа ребят.
          Язык: русский.`,
        },
      });

      const aiText = response.text || "Извините, научный модуль временно недоступен.";
      setMessages(prev => [...prev, { role: 'assistant', text: aiText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', text: "Произошла ошибка в работе ИИ. Попробуйте позже!" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-blue-900/50 border border-blue-400/30 rounded-3xl shadow-2xl overflow-hidden max-w-2xl mx-auto flex flex-col h-[500px]">
      <div className="bg-blue-600 p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <i className="fas fa-robot text-white animate-pulse"></i>
          <span className="font-black text-sm uppercase tracking-tighter">Помощник 6-З</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-ping"></span>
          <div className="text-[10px] font-bold bg-blue-800 px-2 py-1 rounded border border-blue-400/30 tracking-widest uppercase">Research mode</div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 space-y-4 bg-blue-950/30">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-4 text-sm ${
              m.role === 'user' 
                ? 'bg-blue-500 text-white rounded-br-none shadow-lg' 
                : 'bg-blue-800 text-blue-50 border border-blue-400/20 rounded-bl-none shadow-md'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-blue-800 p-3 rounded-2xl rounded-bl-none flex space-x-1">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-75"></div>
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-150"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-blue-900/80 border-t border-blue-400/20 flex space-x-2">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Задай вопрос о мессенджерах..."
          className="flex-grow p-3 bg-blue-950 rounded-xl focus:outline-none border border-blue-400/30 text-white placeholder-blue-300/50 text-sm"
        />
        <button 
          onClick={handleSend}
          disabled={loading}
          className="bg-white text-blue-900 w-12 h-12 rounded-xl flex items-center justify-center hover:bg-blue-100 transition-all active:scale-90 shadow-lg"
        >
          <i className="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  );
};

export default GeminiAssistant;
