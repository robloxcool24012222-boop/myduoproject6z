
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative py-20 lg:py-28 overflow-hidden bg-blue-800">
      {/* Декоративные элементы */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-400/20 rounded-full blur-[100px]"></div>
      
      <div className="container mx-auto px-6 relative z-10 flex flex-col lg:flex-row items-center">
        <div className="lg:w-3/5 text-center lg:text-left mb-16 lg:mb-0">
          <div className="inline-flex items-center bg-blue-900/50 border border-blue-400/30 px-4 py-2 rounded-full mb-8">
            <i className="fas fa-microscope text-blue-400 mr-2"></i>
            <span className="text-xs font-bold tracking-widest uppercase text-blue-100">Первый научный проект учеников 6 «З» класса</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black leading-tight mb-8 tracking-tighter uppercase">
            Мир цифровой <span className="text-blue-400 italic underline decoration-blue-500/50">связи</span>
          </h1>
          
          <p className="text-lg md:text-xl text-blue-100/90 mb-10 max-w-2xl leading-relaxed">
            Добро пожаловать на наш первый серьезный сайт! Мы, ученики 6 «З», провели исследование самых популярных мессенджеров. 
            Мы узнали, как они помогают нам общаться, учиться и развивать свои таланты в интернете.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <a href="#showcase" className="px-8 py-4 bg-white text-blue-900 rounded-2xl font-black text-base hover:shadow-2xl transition-all transform hover:-translate-y-1 text-center">
              ПОСМОТРЕТЬ РАБОТУ
            </a>
            <a href="#assistant" className="px-8 py-4 border-2 border-white/30 text-white rounded-2xl font-bold text-base hover:bg-white/10 transition-all text-center">
              ЗАДАТЬ ВОПРОС ИИ
            </a>
          </div>
        </div>
        
        <div className="lg:w-2/5 flex justify-center">
          <div className="relative w-full max-w-sm aspect-square bg-blue-900/40 rounded-[40px] border-4 border-blue-400/30 flex items-center justify-center overflow-hidden">
            <div className="grid grid-cols-2 gap-6 p-8 relative z-10">
               <div className="w-20 h-20 bg-green-500 rounded-2xl flex items-center justify-center shadow-xl animate-bounce duration-[3000ms]">
                 <i className="fab fa-whatsapp text-4xl"></i>
               </div>
               <div className="w-20 h-20 bg-sky-500 rounded-2xl flex items-center justify-center shadow-xl animate-pulse">
                 <i className="fab fa-telegram text-4xl"></i>
               </div>
               <div className="w-20 h-20 bg-indigo-500 rounded-2xl flex items-center justify-center shadow-xl animate-pulse delay-700">
                 <i className="fab fa-discord text-4xl"></i>
               </div>
               <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center shadow-xl animate-bounce duration-[2500ms]">
                 <i className="fas fa-search text-blue-900 text-3xl"></i>
               </div>
            </div>
            
            <div className="absolute -bottom-6 -right-6 bg-blue-600 border-4 border-blue-400 p-6 rounded-3xl shadow-2xl z-20">
              <span className="text-4xl font-black italic">6-З</span>
              <p className="text-[10px] font-black uppercase tracking-widest mt-1">Авторы</p>
            </div>
            
            {/* Декоративные круги на фоне внутри рамки */}
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-white rounded-full"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border border-white rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
