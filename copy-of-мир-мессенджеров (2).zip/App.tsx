
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import MessengerShowcase from './components/MessengerShowcase';
import GeminiAssistant from './components/GeminiAssistant';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-blue-700">
      <Header />
      <main className="flex-grow">
        <Hero />
        <MessengerShowcase />
        <section id="assistant" className="py-16 bg-blue-800">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
              Умный Помощник
            </h2>
            <p className="text-center mb-12 text-blue-100 max-w-2xl mx-auto">
              Хотите узнать больше о мессенджерах? Спросите наш ИИ-помощник на базе Gemini!
            </p>
            <GeminiAssistant />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;
